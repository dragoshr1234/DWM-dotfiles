This is my personal build of DWM based on bakkeby's flexipatch.

Before you build DWM, you must have installed libxinerama, libxft, libx11 and imlib2.
Also, as my build have systray patches, and enabled battery/powermanager plugins, network plugins and sound plugins, make sure to install:
- xfce4-screenshooter, xfce4-clipman-manager
- volumeicon, pulseaudio, pavucontrol(edit volumeicon accordingly to use pavucontrol)
- network-manager-applet/nm-applet(depends on your distro)
- mate-power-manager
- picom
- rofi
- nitrogen (for background, it will auto install the background you've selected last time
- dunst ( for notifications)-  
- kitty (use my config file to have a transparent terminal)
- sxhkd
- the rest is yours :))

The process is simple, go to DWM folder, and type: "sudo make clean install"
Then copy everything to its directory in $HOME
The default MOD key is the Windows key.
Add "exec dwm" to ~/.xinitrc (copy it from /etc/X11/xinit/xinitrc) and startx. And there you go.
The default keys are Super+Shift+Enter for Terminal
Super + P for Rofi (Apps Menu)
For a better looking icon theme you can install papirus-icon-theme, lxappearance and apply them.

Enjoy :D

