static void floatpos(const Arg *arg);
static void setfloatpos(Client *c, const char *floatpos);
static void getfloatpos(int pos, char pCh, int size, char sCh, int min_p, int max_s, int cp, int cs, int cbw, int defgrid, int *out_p, int *out_s);

