static int getstatusbarpid();
static void sigstatusbar(const Arg *arg);

