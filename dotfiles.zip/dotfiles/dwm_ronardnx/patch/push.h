static Client * nextc(Client *c, float f);
static Client * prevc(Client *c, float f);
static void pushup(const Arg *arg);
static void pushdown(const Arg *arg);

