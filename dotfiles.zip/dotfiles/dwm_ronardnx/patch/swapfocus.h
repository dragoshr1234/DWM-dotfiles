static void swapfocus(const Arg *arg);

