#!/bin/sh

picom &
nm-applet &
volumeicon &
mate-power-manager &
dunst &
xsetroot -name "$(date +%H:%M) | ArtixLinux" &
nitrogen --restore &%
sxhkd -c ~/.local/share/dwm/kb.ini &
xfce4-clipman & 
